package com.example.patpatchat;

public class User {
    private String email, name, profileImageUrl;
}
